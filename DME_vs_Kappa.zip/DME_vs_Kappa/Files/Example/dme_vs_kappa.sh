#!/bin/bash
echo Enter absolute path to Example folder
read $1
echo Enter name of gosia2 input file
read $2
#Script to plot diagonal matrix element vs kappa.
rm kappa_vals.dat Kvals.dat
touch kappa_vals.dat Kvals.dat
#Compile c++ and code to calculate DIPOL (line 699 of gosia2.f) for user specified number of points
g++ -o KVALS kappa_vals.cpp
./KVALS 
#Delete and recreate various files used by script
rm outvals dmevals DMEval DMEvskappa0.dat DMEvskappa.dat
touch outvals dmevals DMEval DMEvskappa0.dat DMEvskappa.dat
#Loop over each value of DIPOL, create gosia2.f, compile and run 
while read -r value; do
./tt.sh $value 
gfortran -o G2dip g2_dip.f
export PATH=$PATH:$1
G2dip < $2.inp
#Change to line number corresponding to final DME printed in .out of input file
sed -n "261,261 p" $2.out > dmevals
cat dmevals|cut -c30-38 dmevals >> DMEval
paste DMEval kappa_vals.dat|column -s $'\t' -t  > DMEvskappa0.dat
done < kappa_vals.dat
paste DMEval Kvals.dat|column -s $'\t' -t  > DMEvskappa.dat
#plot DME vs kappa
python3 plot.py

