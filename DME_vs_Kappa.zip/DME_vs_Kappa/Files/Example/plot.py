import numpy as np
import matplotlib.pyplot as plt 
data = np.loadtxt('DMEvskappa.dat')
# = np.loadtxt('testtt2.dat')
x=data[:,0]
y=data[:,1]
#x2=data[:,0]
#y2=data[:,1]
plt.plot(x,y,'o')
plt.xlabel("DME (eb)")
plt.ylabel("kappa")
#plt.plot(x,y,'o')
plt.show()
