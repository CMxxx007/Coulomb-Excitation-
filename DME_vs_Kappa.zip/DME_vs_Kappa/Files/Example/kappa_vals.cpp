#include<iostream>
#include <fstream>
#include <iomanip>
using namespace std;
fstream outff("kappa_vals.dat");
fstream outf("Kvals.dat");

int main(){
int Np;
double kappa[Np],dipol[Np];
int num,count,total = 0;
//Enter number of points for plot
cout << "ENTER number of POINTS : \n";
cin >> Np;

for (int h=0;h<=Np;h++){
kappa[h] = 0.0 + (2.001/Np)*h;
dipol[h]=0.0038*kappa[h];
outf << setprecision(2)<< kappa[h]<<endl;
outff <<setprecision(2)<< dipol[h] <<endl;
}

return 0;
}
