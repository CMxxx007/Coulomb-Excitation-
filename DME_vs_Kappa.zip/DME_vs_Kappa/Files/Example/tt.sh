#!/bin/bash
touch out00 out11 DIPOL0 
echo '      DIPOL = '$1'D0' > DIPOL0
touch g2_dip.f
./get_g2_lines.sh gosia2_20081208.24_nigel.f 1  698 > out00
./get_g2_lines.sh gosia2_20081208.24_nigel.f 700 13937 > out11 
cat out00 DIPOL0 out11 > g2_dip.f



