#python code to make plot
import numpy as np
import matplotlib.pyplot as plt 
data = np.loadtxt('DMEvskappa.dat')
x=data[:,0]
y=data[:,1]
plt.plot(x,y,'o')
plt.xlabel("DME (eb)")
plt.ylabel("kappa")
plt.show()
