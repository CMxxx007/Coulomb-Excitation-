#!/bin/bash

#if [$# -ne 3]; then
#echo "Usage:$0 <Filename> <lstart> <lend>"
# exit 1
#fi

Filename=$1
lstart=$2 
lend=$3
#numyield=$4

if [ $lstart -gt $lend ]; then
 echo "Error lstart <= lend"
 exit 1
fi 

#touch out00
#touch WNOR_OUT
touch g2_t.f
sed -n "$lstart,$lend p" $Filename 




