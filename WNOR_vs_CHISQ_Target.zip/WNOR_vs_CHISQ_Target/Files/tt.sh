#!/bin/bash
touch out00 out11 WNORT
echo '      WNOR = '$1'D0' > WNORT
touch g2_wn.f
./get_g2_lines.sh gosia2_20081208.24_nigel.f 1  562 > out00
./get_g2_lines.sh gosia2_20081208.24_nigel.f 564 13937 > out11 
cat out00 WNORT out11 > g2_wn.f


