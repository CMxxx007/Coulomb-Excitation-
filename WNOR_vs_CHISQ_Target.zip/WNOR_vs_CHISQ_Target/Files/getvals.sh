#!/bin/bash
touch wnorvschi2.dat
paste WN.dat Chi2val|column -s $'\t' -t  > wnorvschi2.dat
python3 plot.py
