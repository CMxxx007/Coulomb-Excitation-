#!/bin/bash
#Script to determine weighting factor for target normalization (WNOR) in gosia2.f 
echo Enter absolute path to folder containing script and gosia2 MINI files
read var1
echo Enter name of gosia2 MINI input file for projectile
read var2
echo Enter name of gosia2 MINI out file for target
read var3
rm WN.dat
touch WN.dat
#Compile and code to generate user specified number of wnor values
g++ -o WNOR22 Wnor2.cpp
./WNOR22 
#Delete and recreate files required for script
rm outvals chi2vals Chi2val wnorvschi2.dat
touch outvals chi2vals Chi2val wnorvschi2.dat
#loop to read and run gosia2 for each value of wnor in WN.dat and get corresponding value of CHISQ for target 
while read -r value; do
./tt.sh $value 
gfortran -o G2q g2_wn.f
export PATH=$PATH:$var1
G2q < $var2.inp 
grep "*** CHISQ=" $var3.out > outvals
sed -n '$p' outvals > chi2vals
cat chi2vals|cut -c18-30 chi2vals >> Chi2val
paste WN.dat Chi2val|column -s $'\t' -t  > wnorvschi2.dat
done < WN.dat
#plot WNOR vs CHISQ_Target
python3 plot_wnorvschiqt.py

