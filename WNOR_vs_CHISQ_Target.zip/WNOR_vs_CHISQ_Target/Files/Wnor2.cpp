#include<iostream>
#include <fstream>
#include <iomanip>
using namespace std;
fstream outff("WN.dat");

int main(){
int Np;
double wnd[Np];
int num,count,total = 0;
//cout <<"Enter -1 to exit: "; 
cout << "ENTER number of POINTS : \n";
cin >> Np;
//cin >> num;

for (int h=0;h<=Np;h++){
wnd[h] = 0.5 + (0.5/Np)*h;
outff <<setprecision(2)<< wnd[h]<<endl;
}
/*while (num != -1)
{
 total += num;
 count++;
 cout <<"Enter -1 to exit: "; 
 cin >> num;
 }
 cout <<"average is : "
 <<static_cast<double>(total)/count<<endl;*/
return 0;
}
