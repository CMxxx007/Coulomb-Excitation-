import numpy as np
import matplotlib.pyplot as plt 
data = np.loadtxt('wnorvschi2.dat')
x=data[:,0]
y=data[:,1]
plt.plot(x,y,'o')
plt.xlabel("WNOR")
plt.ylabel("CHISQ_Target")
plt.show()
